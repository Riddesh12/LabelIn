import 'package:flutter/material.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  bool _obsureText = true;
  String name = "";
  String email = "";
  String password = "";
  String gender = "";
  int age = 16;
  double height = 5.4;
  int weight = 60;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorScheme.of(context).primary,
      appBar: AppBar(
        backgroundColor: ColorScheme.of(context).onPrimary,
        foregroundColor: ColorScheme.of(context).onSecondary,
        title: const Text(
          "Sign up",
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Your Name',
                  ),
                  onChanged: (value) {
                    setState(() {
                      name = value;
                    });
                  }),
              SizedBox(
                height: 15,
              ),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                validator: (value1) {
                  if (value1 == null || value1.isEmpty)
                    return 'Please enter the Email Address';
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Email:',
                ),
                onChanged: (value) {
                  setState(() {
                    email = value;
                  });
                },
              ),
              SizedBox(
                height: 15,
              ),
              TextFormField(
                obscureText: _obsureText,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please Enter the password';
                  }
                  return null;
                },
                decoration: InputDecoration(
                  labelText: 'Password',
                  suffixIcon: IconButton(
                    icon: Icon(
                        _obsureText ? Icons.visibility : Icons.visibility_off),
                    onPressed: () {
                      setState(() {
                        _obsureText = !_obsureText;
                      });
                    },
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    password = value;
                  });
                },
              ),
              const SizedBox(
                height: 15,
              ),
              Text('Gender:'),
              const SizedBox(
                height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        gender = 'Male';
                      });
                    },
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 40,
                          backgroundImage: AssetImage('assets/male.png'),
                          backgroundColor:
                              gender == 'Male' ? Colors.blue : Colors.grey,
                        ),
                        const SizedBox(height: 5),
                        const Text("Male"),
                      ],
                    ),
                  ),
                  const SizedBox(width: 20),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        gender = 'Female';
                      });
                    },
                    child: Column(
                      children: [
                        CircleAvatar(
                          radius: 40,
                          backgroundImage: AssetImage('assets/female.jpeg'),
                          backgroundColor:
                              gender == 'Female' ? Colors.blue : Colors.grey,
                        ),
                        const SizedBox(height: 5),
                        const Text("Female"),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
