import 'dart:async';

import 'package:flutter/material.dart';
import 'package:test/auth_screen.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    Timer(const Duration(seconds: 5), () {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => AuthScreen()), (route) => (false));
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Hero(
            tag: 'Logo',
            child: Image.asset(
              'assets/images.jpeg',
              height: 100,
              width: 100,
              filterQuality: FilterQuality.high,
            )));
  }
}
