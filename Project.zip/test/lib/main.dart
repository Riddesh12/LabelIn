import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:test/splash_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
          colorScheme: const ColorScheme(
              brightness: Brightness.light,
              primary: Colors.white,
              onPrimary: Colors.green,
              secondary: Colors.grey,
              onSecondary: Colors.grey,
              error: Colors.red,
              onError: Colors.yellow,
              surface: Colors.blue,
              onSurface: Colors.orange)),
      home: SplashPage(),
    );
  }
}
